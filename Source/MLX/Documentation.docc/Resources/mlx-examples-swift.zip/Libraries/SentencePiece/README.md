#  SentencePiece

This is a swift wrapper for the `sentencepiece` api:

- https://github.com/google/sentencepiece

Building requires `sentencepiece` be installed on your system:

```
brew install sentencepiece
```
